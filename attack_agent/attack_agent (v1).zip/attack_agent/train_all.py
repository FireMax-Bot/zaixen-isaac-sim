"""Part 4: train ONE small Random Forest for normal + 17 attacks, and evaluate it honestly.
Run:  python train_all.py     (needs features.csv in the same folder)"""
import os, json, joblib
import numpy as np, pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, f1_score
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt

d = pd.read_csv("features.csv")
F = list(d.columns[8:])
names = ["normal"] + [d[d.cls == i].attack.iloc[0] for i in range(1, 18)]   # names before any filtering
# --- Honest data fixes (found by diagnosis, see report) ---
# 1) missed_contact (cls 7): its data is IDENTICAL to normal (AI_TEAM_GUIDE) -> undetectable, excluded.
d = d[d.cls != 7]
# 2) jump (cls 3): one sudden value, so ~96% of windows inside the attack period contain no jump at all.
#    Keep only windows that really contain one; judge jump at RUN level (alert at least once) in the agent test.
has_jump = (d.maxd1_posx > 1) | (d.maxd1_posy > 1)
print(f"jump windows kept: {int(((d.cls==3)&has_jump).sum())} of {int((d.cls==3).sum())} (others contain no visible jump)")
d = d[~((d.cls == 3) & ~has_jump)]
tr, te = d[d.seed.isin([1, 2])], d[d.seed == 3]          # split by whole runs (seed)
model = RandomForestClassifier(n_estimators=60, max_depth=10, min_samples_leaf=3,
                               class_weight="balanced_subsample", random_state=42, n_jobs=-1)
model.fit(tr[F], tr.cls)
pred = model.predict(te[F]); y = te.cls.to_numpy()

print("train windows", len(tr), "| test windows", len(te))
print(f"\nOverall accuracy: {(pred == y).mean():.3f}   macro-F1: {f1_score(y, pred, average='macro'):.3f}")
rep = classification_report(y, pred, labels=range(18), target_names=names, output_dict=True, zero_division=0)
print("\nPer-class (test, unseen seed 3):")
print(pd.DataFrame(rep).T.loc[names, ["precision", "recall", "f1-score", "support"]].round(2).to_string())

# Detection only: is it an attack, yes/no?
b_true, b_pred = (y > 0), (pred > 0)
print(f"\nDetection (any attack vs normal): recall {b_pred[b_true].mean():.3f} | "
      f"false-alarm rate on normal windows {b_pred[~b_true].mean():.3f}")

# CONTROL TEST: does the model fire during seconds 30-60 of the 9 NORMAL runs? (cheating check)
nt = te[te.attack == "normal"]; p = model.predict(nt[F])
print(f"\nCONTROL (normal runs, unseen): false alarms in 30-60 s: {(p[nt.phase_30_60 == 1] > 0).mean():.3f} | "
      f"outside 30-60 s: {(p[nt.phase_30_60 == 0] > 0).mean():.3f}   (should both be ~0)")

# Which level was hardest?
lv = te[(te.cls > 0) & (te.level > 0)].copy(); lv["ok"] = pred[(te.cls > 0).to_numpy() & (te.level > 0).to_numpy()] == lv.cls
print("\nRecall by strength level (attacks with levels):\n", lv.groupby("level").ok.mean().round(3).to_string())

joblib.dump({"model": model, "features": F, "names": names}, "attack_model.joblib", compress=3)
print(f"\nModel file: {os.path.getsize('attack_model.joblib')/1e6:.2f} MB")

cm = confusion_matrix(y, pred, labels=range(18), normalize="true")
fig, ax = plt.subplots(figsize=(10, 8)); im = ax.imshow(cm, cmap="Blues", vmin=0, vmax=1)
ax.set_xticks(range(18), names, rotation=90, fontsize=7); ax.set_yticks(range(18), names, fontsize=7)
ax.set_xlabel("predicted"); ax.set_ylabel("true"); ax.set_title("Confusion matrix (unseen seed 3, row-normalised)")
plt.colorbar(im); plt.tight_layout(); plt.savefig("confusion_matrix.png", dpi=120)
json.dump({"accuracy": float((pred == y).mean()), "per_class": {k: rep[k] for k in names}}, open("results.json", "w"), indent=1)
