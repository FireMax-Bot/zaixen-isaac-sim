"""Feature extraction for the 17-attack agent.  numpy only (no pandas) so the SAME code
runs in training AND inside the low-RAM agent.

Input per decision:
  a  : aligned window  (100 rows = 2 s at 50 Hz, columns in ACOLS order)
  t  : telemetry rows inside that window (about 4 rows, columns in TCOLS order)
  base: 'normal' telemetry baseline (median of the calm period 15-28 s)
Features describe the HEALTH of the data stream (timing, repeats, jumps, consistency,
network counts) - NOT where the car is driving - so the model cannot cheat by learning
the car's driving script."""
import numpy as np

ACOLS = ["imu.orientation.x", "imu.orientation.y", "imu.orientation.z", "imu.orientation.w",
         "imu.angular_velocity.z", "imu.linear_acceleration.x", "imu.age_s", "imu.stamp_lag_s",
         "odom.pose.pose.position.x", "odom.pose.pose.position.y",
         "odom.pose.pose.orientation.x", "odom.pose.pose.orientation.y",
         "odom.pose.pose.orientation.z", "odom.pose.pose.orientation.w",
         "odom.twist.twist.linear.x", "odom.twist.twist.linear.y", "odom.twist.twist.angular.z",
         "odom.age_s", "odom.stamp_lag_s", "contact.data", "contact.age_s"]
TCOLS = ["imu_mon.rate_hz", "odom_mon.rate_hz", "contact_mon.rate_hz",
         "imu_mon.pub_count", "odom_mon.pub_count", "contact_mon.pub_count",
         "imu_mon.sub_count", "odom_mon.sub_count", "contact_mon.sub_count", "node_count",
         "imu_mon.max_gap_s", "odom_mon.max_gap_s", "contact_mon.max_gap_s",
         "imu_mon.stamp_lag_mean_s", "odom_mon.stamp_lag_mean_s",
         "imu_mon.late_count", "odom_mon.late_count",
         "param_event_count", "service_call_count", "new_nodes_flag"]
A = {c: i for i, c in enumerate(ACOLS)}
DT = 0.02
CALM = (15.0, 28.0)            # seconds: attack-free period used to learn the baseline

FEATURE_NAMES = (
    ["imu_age_max", "imu_age_mean", "odom_age_max", "odom_age_mean", "contact_age_max",
     "imu_lag_mean", "imu_lag_max", "odom_lag_mean", "odom_lag_max",                     # timing (9)
     "imu_zero_frac", "odom_zero_frac"]                                                  # freeze (2)
    + [f"d2std_{n}" for n in ("gyroz", "accx", "posx", "posy", "velx", "angz")]           # noise (6)
    + [f"maxd1_{n}" for n in ("posx", "posy", "accx", "gyroz", "velx")]                   # jump (5)
    + [f"imu_odom_q{k}" for k in "xyzw"] + ["imu_odom_gyro", "pos_speed_mismatch"]        # consistency (6)
    + ["contact_max", "contact_mean"]                                                     # contact (2)
    + [f"rate_ratio_{n}" for n in ("imu", "odom", "contact")]                             # network (20)
    + [f"d_pub_{n}" for n in ("imu", "odom", "contact")]
    + [f"d_sub_{n}" for n in ("imu", "odom", "contact")] + ["d_node_count"]
    + [f"maxgap_{n}" for n in ("imu", "odom", "contact")]
    + ["tlag_imu", "tlag_odom", "late_imu", "late_odom", "param_events", "service_calls", "new_nodes"]
)

def aligned_features(a):
    g = lambda name: a[:, A[name]]
    d1 = np.abs(np.diff(a, axis=0)); d2 = np.diff(a, n=2, axis=0)
    zf = lambda names: float(np.mean([(d1[:, A[n]] == 0).mean() for n in names]))
    f = [g("imu.age_s").max(), g("imu.age_s").mean(), g("odom.age_s").max(), g("odom.age_s").mean(),
         g("contact.age_s").max(),
         g("imu.stamp_lag_s").mean(), g("imu.stamp_lag_s").max(),
         g("odom.stamp_lag_s").mean(), g("odom.stamp_lag_s").max(),
         zf(["imu.orientation.z", "imu.angular_velocity.z", "imu.linear_acceleration.x"]),
         zf(["odom.pose.pose.position.x", "odom.pose.pose.position.y", "odom.twist.twist.linear.x"])]
    for n in ("imu.angular_velocity.z", "imu.linear_acceleration.x", "odom.pose.pose.position.x",
              "odom.pose.pose.position.y", "odom.twist.twist.linear.x", "odom.twist.twist.angular.z"):
        f.append(d2[:, A[n]].std())
    for n in ("odom.pose.pose.position.x", "odom.pose.pose.position.y", "imu.linear_acceleration.x",
              "imu.angular_velocity.z", "odom.twist.twist.linear.x"):
        f.append(d1[:, A[n]].max())
    for k in "xyzw":
        f.append(np.abs(g(f"imu.orientation.{k}") - g(f"odom.pose.pose.orientation.{k}")).mean())
    f.append(np.abs(g("imu.angular_velocity.z") - g("odom.twist.twist.angular.z")).mean())
    T = (len(a) - 1) * DT
    disp = np.hypot(a[-1, A["odom.pose.pose.position.x"]] - a[0, A["odom.pose.pose.position.x"]],
                    a[-1, A["odom.pose.pose.position.y"]] - a[0, A["odom.pose.pose.position.y"]])
    speed = np.hypot(g("odom.twist.twist.linear.x"), g("odom.twist.twist.linear.y")).mean()
    f.append(abs(disp - speed * T) / T)
    f += [np.abs(g("contact.data")).max(), g("contact.data").mean()]
    return np.nan_to_num(np.array(f, dtype=np.float32))

def telemetry_baseline(tcalm):
    """tcalm: telemetry rows from the calm period (k x len(TCOLS))."""
    return np.nan_to_num(np.nanmedian(tcalm, axis=0))

def telemetry_features(t, base):
    if len(t) == 0:
        return np.zeros(20, dtype=np.float32)
    nm, nx, ns = np.nanmean, np.nanmax, np.nansum
    f = list(nm(t[:, 0:3], axis=0) / (base[0:3] + 1e-6))
    f += list(nx(np.abs(t[:, 3:10] - base[3:10]), axis=0))
    f += list(nx(t[:, 10:13], axis=0) - base[10:13])                       # gaps, relative to this run's normal
    f += list(nm(t[:, 13:15], axis=0) - base[13:15])                       # timestamp lag, relative
    f += list(ns(t[:, 15:17], axis=0) - base[15:17] * len(t))              # late messages, relative
    f += [ns(t[:, 17]), ns(t[:, 18]), nx(t[:, 19])]
    return np.nan_to_num(np.array(f, dtype=np.float32))

N_REL = 11     # the first 11 aligned features (9 timing + 2 repeat) are made relative to the run's own calm period

def aligned_baseline(calm_feats):
    """calm_feats: aligned_features() of every window inside the calm period -> per-run 'normal' level."""
    return np.median(np.array(calm_feats)[:, :N_REL], axis=0)

def window_features(a, t, base, abase=None):
    af = aligned_features(a)
    if abase is not None:
        af[:N_REL] = af[:N_REL] - abase
    return np.concatenate([af, telemetry_features(t, base)])

assert len(FEATURE_NAMES) == 50
