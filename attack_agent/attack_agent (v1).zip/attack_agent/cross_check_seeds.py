"""Extra honesty check: leave-one-seed-out.  Each seed takes a turn as the unseen test set.
If the results are similar for all three seeds, the good scores are not luck of one split.
Run:  python cross_check_seeds.py      (needs features.csv in the same folder)"""
import numpy as np, pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score

d = pd.read_csv("features.csv"); F = list(d.columns[8:])
d = d[d.cls != 7]                                                    # missed_contact: undetectable (same as train_all.py)
d = d[~((d.cls == 3) & ~((d.maxd1_posx > 1) | (d.maxd1_posy > 1)))]  # jump: only windows that contain a jump
rows = []
for test_seed in (1, 2, 3):
    tr, te = d[d.seed != test_seed], d[d.seed == test_seed]
    m = RandomForestClassifier(n_estimators=60, max_depth=10, min_samples_leaf=3, class_weight="balanced_subsample",
                               random_state=42, n_jobs=-1).fit(tr[F], tr.cls)
    p = m.predict(te[F]); y = te.cls.to_numpy()
    nt = te[te.attack == "normal"]; pn = m.predict(nt[F])
    rows.append(dict(test_seed=test_seed, accuracy=(p == y).mean(), macro_F1=f1_score(y, p, average="macro"),
                     attack_recall=(p[y > 0] > 0).mean(), false_alarm_normal=(p[y == 0] > 0).mean(),
                     control_30_60=(pn[nt.phase_30_60 == 1] > 0).mean()))
R = pd.DataFrame(rows).round(3); print(R.to_string(index=False)); print("\nmean:\n", R.mean().round(3).to_string())
