"""Run the trained Random Forest with numpy only (no scikit-learn) -> much lower RAM for the agent.
  python tiny_forest.py        converts attack_model.joblib -> attack_model.npz and checks they agree."""
import numpy as np

class TinyForest:
    def __init__(self, path="attack_model.npz"):
        z = np.load(path, allow_pickle=False)
        self.left, self.right, self.feat, self.thr, self.val = z["left"], z["right"], z["feat"], z["thr"], z["val"]
        self.classes = z["classes"]
        self.names = [str(n) for n in z["names"]]

    def predict_proba(self, x):
        """x: 1-D feature vector -> probability for each entry of self.classes."""
        p = np.zeros(self.val.shape[2], dtype=np.float32)
        for t in range(self.left.shape[0]):
            n = 0
            L, R, F, T = self.left[t], self.right[t], self.feat[t], self.thr[t]
            while L[n] != -1:
                n = L[n] if x[F[n]] <= T[n] else R[n]
            p += self.val[t, n]
        return p / self.left.shape[0]

def export(joblib_path="attack_model.joblib", out="attack_model.npz"):
    import joblib
    b = joblib.load(joblib_path); m = b["model"]
    k = max(e.tree_.node_count for e in m.estimators_); n_t, n_c = len(m.estimators_), len(m.classes_)
    left = -np.ones((n_t, k), np.int32); right = -np.ones((n_t, k), np.int32)
    feat = np.zeros((n_t, k), np.int16); thr = np.zeros((n_t, k), np.float32); val = np.zeros((n_t, k, n_c), np.float16)
    for i, e in enumerate(m.estimators_):
        t = e.tree_; c = t.node_count
        left[i, :c], right[i, :c], feat[i, :c] = t.children_left, t.children_right, np.maximum(t.feature, 0)
        thr[i, :c] = t.threshold
        v = t.value[:, 0, :]; val[i, :c] = v / v.sum(axis=1, keepdims=True)
    np.savez_compressed(out, left=left, right=right, feat=feat, thr=thr, val=val,
                        classes=m.classes_.astype(np.int16), names=np.array(b["names"]))
    return m, b

if __name__ == "__main__":
    import os, pandas as pd
    m, b = export()
    tf = TinyForest(); d = pd.read_csv("features.csv"); F = b["features"]
    s = d[d.cls != 7].sample(1500, random_state=0)
    X = s[F].to_numpy(np.float32)
    mine = np.array([tf.classes[tf.predict_proba(x).argmax()] for x in X]); ref = m.predict(X)
    print(f"agreement with scikit-learn: {(mine == ref).mean():.4f} on {len(X)} windows")
    print(f"attack_model.npz size: {os.path.getsize('attack_model.npz')/1e3:.0f} KB")
