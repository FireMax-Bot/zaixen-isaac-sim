"""Part 1: audit all 17 abnormal-type folders. Run:  python audit_data.py <path_to_folder_containing_01_noise,02_bias_drift,...>
Prints a short report and saves audit_report.txt  (paste the report back to Claude)."""
import os, sys, glob, json, gzip
import pandas as pd

root = sys.argv[1] if len(sys.argv) > 1 else "."
out = []
def say(*a):
    s = " ".join(str(x) for x in a); print(s); out.append(s)

types = sorted(d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d)) and d[:2].isdigit())
say(f"Found {len(types)} type folders in {os.path.abspath(root)}\n")
base_cols = None
for t in types:
    tdir = os.path.join(root, t)
    runs = sorted(d for d in os.listdir(tdir) if os.path.isdir(os.path.join(tdir, d)))
    size_mb = sum(os.path.getsize(os.path.join(dp, f)) for dp, _, fs in os.walk(tdir) for f in fs) / 1e6
    say(f"=== {t} | runs: {len(runs)} | size: {size_mb:.1f} MB")
    if not runs:
        say("   (no run folders)"); continue
    r0 = os.path.join(tdir, runs[0])
    say("   example run:", runs[0], "| files:", sorted(os.listdir(r0)))
    al = os.path.join(r0, "aligned.csv.gz")
    if os.path.exists(al):
        df = pd.read_csv(al)
        cols = list(df.columns)
        if base_cols is None: base_cols = set(cols)
        extra = sorted(set(cols) - base_cols); missing = sorted(base_cols - set(cols))
        say(f"   aligned rows: {len(df)} | columns: {len(cols)} | new vs first type: {extra[:8]} | missing: {missing[:8]}")
        for c in ("is_attack", "attack_type"):
            if c in df: say(f"   {c}:", df[c].value_counts().to_dict())
        if "is_attack" in df and "t_rel_s" in df and df.is_attack.sum():
            a = df[df.is_attack == 1].t_rel_s
            say(f"   attack window: {a.min():.1f}s - {a.max():.1f}s of {df.t_rel_s.max():.1f}s")
    mf = os.path.join(r0, "manifest.json")
    if os.path.exists(mf):
        m = json.load(open(mf)); say("   manifest keys:", list(m.keys())[:15])
    ev = os.path.join(r0, "events.csv")
    if os.path.exists(ev):
        e = pd.read_csv(ev); say(f"   events rows: {len(e)} | columns: {list(e.columns)[:8]}")
    tl = os.path.join(r0, "telemetry.csv.gz")
    if os.path.exists(tl):
        d = pd.read_csv(tl, nrows=3); say(f"   telemetry columns ({len(d.columns)}):", list(d.columns)[:10])
    say("")
open("audit_report.txt", "w").write("\n".join(out))
say("Saved audit_report.txt")
