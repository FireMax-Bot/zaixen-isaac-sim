"""Part 3: turn all runs into one small feature table.   Run from anywhere:
    python build_features.py <AI_team_data folder>      (the one containing normal_data and abnormal_data)
Creates features.csv  (one row per 2-second window, 50 features + labels).  Takes a few minutes."""
import os, re, sys, glob, warnings
import numpy as np, pandas as pd
from features import *
warnings.filterwarnings("ignore")

root = sys.argv[1] if len(sys.argv) > 1 else "."
WIN, STEP, START = 100, 50, 15.0                  # 2 s windows, 1 s step, skip start-up (<15 s)
rows = []

def run_list():
    for d in sorted(glob.glob(os.path.join(root, "normal_data", "*"))):
        yield d, 0, "normal"
    for d in sorted(glob.glob(os.path.join(root, "abnormal_data", "[0-9][0-9]_*", "*"))):
        if os.path.isdir(d):
            tdir = os.path.basename(os.path.dirname(d))
            yield d, int(tdir[:2]), tdir[3:]

for folder, atk_no, atk_name in run_list():
    ap, tp = [os.path.join(folder, f) for f in ("aligned.csv.gz", "telemetry.csv.gz")]
    if not (os.path.exists(ap) and os.path.exists(tp)): continue
    name = os.path.basename(folder)
    lvl = re.search(r"_L(\d)_", name); npc = re.search(r"npc(\d+)", name); seed = re.search(r"seed(\d+)", name)
    al, tl = pd.read_csv(ap), pd.read_csv(tp)
    t0 = al["sim_time_s"].iloc[0] - al["t_rel_s"].iloc[0]
    tl["t_rel"] = tl["sim_time_s"] - t0
    tl["new_nodes_flag"] = tl["new_nodes"].fillna("").astype(str).str.len().gt(0).astype(float) if "new_nodes" in tl else 0.0
    TT = tl.reindex(columns=TCOLS).to_numpy(float); tt = tl["t_rel"].to_numpy()
    base = telemetry_baseline(TT[(tt >= CALM[0]) & (tt <= CALM[1])])
    AA = al.reindex(columns=ACOLS).to_numpy(float); ar = al["t_rel_s"].to_numpy()
    atk = al["is_attack"].to_numpy() if "is_attack" in al else np.zeros(len(al))
    s0 = int(np.searchsorted(ar, START))
    wins = []                                                          # pass 1: raw aligned features of every window
    for s in range(s0, len(al) - WIN + 1, STEP):
        wins.append((s, ar[s], ar[s + WIN - 1], atk[s:s + WIN].mean(), aligned_features(AA[s:s + WIN])))
    calm = [w[4] for w in wins if w[2] <= CALM[1]]                     # windows that END inside the calm period
    abase = aligned_baseline(calm) if calm else np.zeros(N_REL, dtype=np.float32)
    for s, ts, te, frac, _ in wins:                                    # pass 2: final features
        if te <= CALM[1]: continue                                     # the agent only learns here, never scores
        if 0 < frac < 1: continue                                      # drop mixed boundary windows
        tmask = (tt >= ts) & (tt < te + DT)
        feats = window_features(AA[s:s + WIN], TT[tmask], base, abase)
        rows.append([name, atk_no if frac == 1 else 0, atk_name, int(lvl.group(1)) if lvl else (0 if atk_no == 0 else 1),
                     int(npc.group(1)) if npc else 0, int(seed.group(1)) if seed else 0,
                     round(ts, 2), int(30 <= ts < 60)] + list(feats))
    print("done", name, end="\r")

cols = ["run", "cls", "attack", "level", "npc", "seed", "t_start", "phase_30_60"] + FEATURE_NAMES
df = pd.DataFrame(rows, columns=cols)
df.to_csv("features.csv", index=False, float_format="%.5g")
print(f"\nSaved features.csv: {len(df)} windows, {df.run.nunique()} runs, {os.path.getsize('features.csv')/1e6:.1f} MB")
print(df.groupby(["cls", "attack"]).size().rename("windows").to_string())
