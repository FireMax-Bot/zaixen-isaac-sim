"""Part 2: which columns change during each attack?  Run:  python signatures.py .
For every type, compares NORMAL vs ATTACK periods in aligned.csv.gz and telemetry.csv.gz
and prints the top columns that react.  Paste signatures_report.txt back to Claude."""
import os, sys, glob
import numpy as np, pandas as pd

root = sys.argv[1] if len(sys.argv) > 1 else "."
EXCL = ("time", "t_rel", "is_attack", "attack_", "run_id", "sim_time")
out = []
def say(s=""): print(s); out.append(s)

def score(df):
    """Per numeric column: z = shift of the mean, r = change in jitter (std of diff). Returns DataFrame."""
    a = df[df.is_attack == 1]
    t0, t1 = a.iloc[0]["__t"], a.iloc[-1]["__t"]
    n = df[(df.__t < t0 - 1) | (df.__t > t1 + 1)]
    rows = []
    for c in df.columns:
        if c.startswith("__") or any(k in c for k in EXCL) or not pd.api.types.is_numeric_dtype(df[c]): continue
        x, y = n[c].astype(float), a[c].astype(float)
        if x.isna().all() or y.isna().all(): continue
        z = abs(y.mean() - x.mean()) / (x.std() + 1e-9)
        jn, ja = x.diff().std(), y.diff().std()
        r = abs(np.log(ja / jn)) if (jn > 1e-6 and ja > 1e-6) else 0.0          # jitter change
        dn, da = x.diff(), y.diff()                                             # growth-rate change (for counters)
        g = abs(da.mean() - dn.mean()) / (dn.std() + 1e-3 * abs(dn.mean()) + 1e-3)
        rows.append((c, round(min(z, 99), 2), round(min(max(r, g / 10), 99), 2)))
    return pd.DataFrame(rows, columns=["column", "mean_shift_z", "jitter_logratio"])

types = sorted(d for d in os.listdir(root) if d[:2].isdigit() and os.path.isdir(os.path.join(root, d)))
for t in types:
    runs = sorted(glob.glob(os.path.join(root, t, "*npc10_seed1")))
    if not runs: continue
    run = runs[-1]                                   # strongest level (L3) if levels exist
    say(f"=== {t}   (run: {os.path.basename(run)})")
    for fname, tcol in (("aligned", "t_rel_s"), ("telemetry", "sim_time_s")):
        df = pd.read_csv(os.path.join(run, fname + ".csv.gz"))
        df["__t"] = df[tcol] - df[tcol].min()
        s = score(df)
        s["best"] = s[["mean_shift_z", "jitter_logratio"]].max(axis=1)
        top = s.sort_values("best", ascending=False).head(5)
        say(f"  [{fname}] top reacting columns (shift_z / jitter-or-rate change):")
        for _, r in top.iterrows():
            say(f"     {r.column:55s} {r.mean_shift_z:8.2f} {r.jitter_logratio:6.2f}")
    say()
open("signatures_report.txt", "w").write("\n".join(out))
