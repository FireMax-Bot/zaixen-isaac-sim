"""Attack-detection agent for the autonomous-car sensor stream.  numpy only.
Perceive -> Decide (model) -> Smooth (voting) -> Act.

How to use:
    agent = AttackAgent()
    agent.feed_telemetry(tel_row, t)         # 2 Hz network row   (order = features.TCOLS)
    out = agent.feed_aligned(row, t)         # 50 Hz sensor row   (order = features.ACOLS)
    # out is None, or a decision dict every 0.5 s: {"t","state","attack","confidence","action"}
t = seconds since the run started. The agent learns the 'normal' network baseline by itself
from the calm period 15-28 s (attacks never start before 30 s)."""
from collections import deque, Counter
import numpy as np
from features import window_features, aligned_features, aligned_baseline, telemetry_baseline, CALM, DT
from tiny_forest import TinyForest

WIN, STEP, START = 100, 50, 15.0

ACTIONS = {
    "noise": "Flag IMU/odometry as unreliable; smooth or fall back to last trusted estimate",
    "bias_drift": "Flag orientation/odometry as drifting; cross-check IMU against odometry",
    "jump": "Reject the impossible value; hold last valid reading",
    "freeze": "Mark sensor as stuck; switch to redundant source",
    "replay": "Treat data as stale/replayed; request fresh data and verify timestamps",
    "false_contact": "Ignore contact signal; confirm with other sensors before reacting",
    "missed_contact": "Cross-check contact sensor with IMU",
    "delay": "Mark stream as late; check network link and timestamps",
    "drop": "Mark stream as lossy; switch to backup channel",
    "duplicate": "Deduplicate messages by timestamp; check publisher",
    "clock_skew": "Re-synchronise clocks; distrust message timestamps",
    "flood": "Rate-limit the topic; alert operator",
    "spoof": "Block the unknown publisher; trust only the authorised sensor",
    "unauthorized_node": "Quarantine the unknown node; review the node list",
    "unauthorized_subscription": "Review topic subscribers; enable access control",
    "param_tamper": "Restore known-good parameters; lock parameter changes",
    "service_abuse": "Rate-limit service calls; review the caller",
}

class AttackAgent:
    def __init__(self, model_path="attack_model.npz", vote_n=5, vote_k=3):
        self.model = TinyForest(model_path)
        self.names, self.classes = self.model.names, self.model.classes
        self.buf = deque(maxlen=WIN)                 # last 2 s of sensor rows
        self.tel = deque(maxlen=24)                  # last ~12 s of network rows
        self.calm = []                               # network rows from 15-28 s
        self.base = None; self.abase = None; self.acalm = []   # baselines learned in the calm period
        self.last_features = None
        self.votes = deque(maxlen=vote_n); self.k = vote_k
        self.n = 0                                   # rows seen since 15 s

    def feed_telemetry(self, row, t):
        row = np.asarray(row, dtype=float)
        self.tel.append((t, row))
        if CALM[0] <= t <= CALM[1]:
            self.calm.append(row)

    def feed_aligned(self, row, t):
        if t < START:
            return None
        self.buf.append((t, np.asarray(row, dtype=float))); self.n += 1
        if len(self.buf) < WIN or (self.n - WIN) % STEP != 0:
            return None
        a = np.array([r for _, r in self.buf])
        if t <= CALM[1] or not self.calm:                                  # still learning what 'normal' looks like
            self.acalm.append(aligned_features(a))
            return {"t": t, "state": "CALIBRATING", "attack": None, "confidence": 0.0, "action": "Learning normal baseline"}
        if self.base is None:
            self.base = telemetry_baseline(np.array(self.calm)); self.abase = aligned_baseline(self.acalm)
        ts, te = self.buf[0][0], self.buf[-1][0]
        tel = np.array([r for tt, r in self.tel if ts <= tt < te + DT]).reshape(-1, self.base.size)
        self.last_features = window_features(a, tel, self.base, self.abase)
        p = self.model.predict_proba(self.last_features)   # perceive + decide
        i = int(p.argmax()); cls = int(self.classes[i]); conf = float(p[i])
        name = self.names[cls]
        self.votes.append(cls)                                              # smooth
        if cls == 3:                                                        # jump = one-off event: counts as 3 votes
            self.votes.append(cls); self.votes.append(cls)
        bad = [v for v in self.votes if v != 0]
        if len(bad) >= self.k:                                              # act
            atk = self.names[Counter(bad).most_common(1)[0][0]]
            return {"t": t, "state": "ALERT", "attack": atk, "confidence": round(conf, 3), "action": ACTIONS.get(atk, "Alert operator")}
        return {"t": t, "state": "OK", "attack": None, "confidence": round(conf, 3), "action": "No action"}
