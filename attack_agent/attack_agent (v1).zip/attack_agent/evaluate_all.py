"""Part 5: evaluate the AGENT by replaying unseen runs (seed 3) as a live stream.
    python evaluate_all.py <AI_team_data folder>
Saves agent_results.csv, agent_summary.csv and agent_summary.png."""
import os, re, sys, glob, time, tracemalloc, warnings
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from features import ACOLS, TCOLS
from agent_all import AttackAgent
warnings.filterwarnings("ignore")
root = sys.argv[1] if len(sys.argv) > 1 else "."

def runs():
    for d in sorted(glob.glob(os.path.join(root, "normal_data", "*seed3*"))):
        yield d, "normal"
    for d in sorted(glob.glob(os.path.join(root, "abnormal_data", "[0-9][0-9]_*", "*seed3*"))):
        yield d, os.path.basename(os.path.dirname(d))[3:]

def load(folder):
    al = pd.read_csv(os.path.join(folder, "aligned.csv.gz")); tl = pd.read_csv(os.path.join(folder, "telemetry.csv.gz"))
    t0 = al["sim_time_s"].iloc[0] - al["t_rel_s"].iloc[0]
    tl["t_rel"] = tl["sim_time_s"] - t0
    tl["new_nodes_flag"] = tl["new_nodes"].fillna("").astype(str).str.len().gt(0).astype(float) if "new_nodes" in tl else 0.0
    return (al.reindex(columns=ACOLS).to_numpy(float), al["t_rel_s"].to_numpy(),
            tl.reindex(columns=TCOLS).to_numpy(float), tl["t_rel"].to_numpy(),
            al["is_attack"].to_numpy() if "is_attack" in al else np.zeros(len(al)))

def replay(agent, AA, ar, TT, tt):
    """Feed the stream in time order; return list of decisions and seconds spent."""
    out, j, t_start = [], 0, time.perf_counter()
    for i in range(len(AA)):
        while j < len(TT) and tt[j] <= ar[i]:
            agent.feed_telemetry(TT[j], tt[j]); j += 1
        r = agent.feed_aligned(AA[i], ar[i])
        if r: out.append(r)
    return out, time.perf_counter() - t_start

rows = []
for folder, atk in runs():
    name = os.path.basename(folder); lv = re.search(r"_L(\d)_", name)
    AA, ar, TT, tt, lab = load(folder)
    dec, secs = replay(AttackAgent(), AA, ar, TT, tt)
    D = pd.DataFrame(dec); D = D[D.state != "CALIBRATING"]
    alert = D.state == "ALERT"
    rec = dict(run=name, attack=atk, level=int(lv.group(1)) if lv else 0, ms_per_decision=round(secs / max(len(dec), 1) * 1000, 2))
    if lab.sum() > 0:
        a0, a1 = ar[lab == 1].min(), ar[lab == 1].max()
        inw = D[(D.t >= a0) & (D.t <= a1 + 2)]; al_in = inw[inw.state == "ALERT"]
        rec.update(detected=len(al_in) > 0,
                   delay_s=round(al_in.t.min() - a0, 2) if len(al_in) else np.nan,
                   correct_type=bool(len(al_in) and al_in.attack.mode().iloc[0] == atk),
                   fa_before=round(alert[(D.t < a0 - 1)].mean(), 3), fa_after=round(alert[(D.t > a1 + 3)].mean(), 3))
    else:
        rec.update(fa_before=round(alert[D.t < 30].mean(), 3), fa_after=round(alert[D.t >= 30].mean(), 3))   # control: normal run
    rows.append(rec); print("done", name, end="\r")
R = pd.DataFrame(rows); R.to_csv("agent_results.csv", index=False)

A = R[R.attack != "normal"]
S = A.groupby("attack", sort=False).agg(runs=("run", "size"), detected=("detected", "mean"), correct_type=("correct_type", "mean"),
                                        median_delay_s=("delay_s", "median"), false_alarm_before=("fa_before", "mean"),
                                        false_alarm_after=("fa_after", "mean")).round(2)
S.to_csv("agent_summary.csv"); print("\n\nPer-attack results (unseen seed 3 runs):\n", S.to_string())
N = R[R.attack == "normal"]
print(f"\nCONTROL - normal runs: alert rate during whole run {N.fa_after.mean():.3f} (30 s on) / {N.fa_before.mean():.3f} (before 30 s)")
print(f"Overall detection {A.detected.mean():.1%} | correct attack type {A.correct_type.mean():.1%} | median delay {A.delay_s.median():.1f}s")
lvl = A[A.level > 0].groupby("level").detected.mean().round(2).to_dict(); print("Detection by strength level:", lvl)
print(f"Speed: {R.ms_per_decision.mean():.2f} ms per decision (one decision every 500 ms)")

# memory: load model + replay one full run, measure Python-allocated peak
AA, ar, TT, tt, _ = load(runs().__next__()[0]); tracemalloc.start()
ag = AttackAgent(); replay(ag, AA, ar, TT, tt); peak = tracemalloc.get_traced_memory()[1] / 1e6; tracemalloc.stop()
print(f"Agent peak memory (numpy arrays + model, one run): {peak:.1f} MB | model file: {os.path.getsize('attack_model.npz')/1e3:.0f} KB")
try:
    import psutil; print(f"Whole process RSS (includes pandas used by this evaluator): {psutil.Process().memory_info().rss/1e6:.0f} MB")
except Exception: pass

fig, ax = plt.subplots(figsize=(10, 4)); x = np.arange(len(S))
ax.bar(x - .2, S.detected, .4, label="detected"); ax.bar(x + .2, S.correct_type, .4, label="correct type")
ax.set_xticks(x, S.index, rotation=70, ha="right", fontsize=8); ax.set_ylim(0, 1.05); ax.legend(); ax.set_title("Agent on unseen runs")
plt.tight_layout(); plt.savefig("agent_summary.png", dpi=120)
